//Función para insertar elemento en el campus
function setChildrenToElementById(id) {
    const rowElement = document.querySelector('.columnaHome.card');
    rowElement.classList.add('roundedhome');
    const targetElement = document.getElementById(id);
    rowElement.appendChild(targetElement);
    Array.from(rowElement.children).forEach(child => {
        if (child.id !== id) {
            child.remove();
        }
    });
}

//Función para colocar el link al grupo correcto
function groupLink(course){
    let groups = {
        nr3a: 23366,
        nr3b: 23382,
        nr3e: 23427,
    };
    let groupLink = document.getElementById('grupo');
    console.log(`https://campus.ort.edu.ar/grupo/${groups[course]}`);
    groupLink.href = `https://campus.ort.edu.ar/grupo/${groups[course]}`;
}

//Función para ver si está corriendo en el campus o de forma independiente
function onCampus(){
    const campusPath = new RegExp(".(campus.ort.edu.ar).");
    const pathname = window.location.pathname;
    return campusPath.test(pathname);
}

//Función para ver en que curso está embebido
function course(){
    const pathname = window.location.pathname;
    const course = pathname.split('/')[4].split('-')[1].toLocaleLowerCase();
    return course;
}

//Función para ver que actividades cargar
function loadJSON(path, success, error) {
    var xhr = new XMLHttpRequest();
    xhr.onreadystatechange = function () {
      if (xhr.readyState === 4) {
        if (xhr.status === 200) {
          success(JSON.parse(xhr.responseText));
        }
        else {
          error(xhr);
        }
      }
    };
    xhr.open('GET', path + '?_=' + new Date().getTime(), true);
    xhr.send();
}

//Función para habilitar las actividades ocultas
function enableActivities(activities,course){
    Object.keys(activities).forEach(activity => {
        if ((activities[activity][course])){
            document.getElementById(activity).classList.remove('hidden');
        }
    });
    document.getElementById('shulianLoading').classList.add('hidden');
}

//Función para cambiar entre pestañas de la home
function show(id){
    let subPages = ["activities","material"];
    if (subPages.includes(id)){
        subPages.forEach(subPage => {
            if (subPage !== id){
                document.getElementById(subPage).classList.add('hidden');
            } else {
                document.getElementById(subPage).classList.remove('hidden');
            }
        });
    }
}

//Setup al cargar
document.addEventListener('DOMContentLoaded', () => {
    // Valor default para pruebas
    let courseName = 'nr3a';
    if(onCampus()){
        setChildrenToElementById('customhome');
        courseName = course();
    }
    loadJSON("https://jzylber.github.io/campus-data/data.json", (activities) => enableActivities(activities,courseName),'jsonp');
    groupLink(courseName);
    document.getElementById('home').addEventListener('click', () => show('activities'));
    document.getElementById('materialButton').addEventListener('click', () => show('material'));
});

