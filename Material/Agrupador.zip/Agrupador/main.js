// Implementación de Shulian de https://en.wikipedia.org/wiki/Fisher%E2%80%93Yates_shuffle
function mezclarArray(array) {
  for (let i = 0; i <= array.length - 2; i++) {
    let j = Math.floor(Math.random() * array.length);
    let temp = array[i];
    array[i] = array[j];
    array[j] = temp;
  }
}

function crearGrupos(event) {
  event.preventDefault();
  // Spliteo en base a los saltos de línea (enter)
  let lista = event.target.lista.value.split("\n");
  let tamañoGrupo = parseInt(event.target.tamano.value);
  // Limpio los tabs y comillas que me da copiar y pegar de drive
  for (let i = 0; i < lista.length; i++) {
    // No me odien pero Regex es lo más
    lista[i] = lista[i].replace(/\t/g, " ").replace(/"/g, "").trim();
  }
  // Filtro los elementos vacíos
  lista = lista.filter((elemento) => elemento !== "");
  // Si la lista está vacía, salgo de la funcíon
  if (lista.length === 0) {
    alert("No hay nombres en la lista");
    return;
  }
  // Mezclo la lista
  mezclarArray(lista);
  let grupos = [];
  let grupoActual = [];
  for (let i = 0; i < lista.length; i++) {
    grupoActual.push(lista[i]);
    // Si el grupo actual llega al tamaño deseado y quedan suficientes miembros para 1 grupo, o si es el último miembro
    if (
      (grupoActual.length === tamañoGrupo && lista.length - i > tamañoGrupo) ||
      i === lista.length - 1
    ) {
      // Agrego a la lista de grupos y lo reinicio
      grupos.push(grupoActual);
      grupoActual = [];
    }
  }
  // Limpio el div de los grupos anteriores
  let divGrupos = document.getElementById("grupos");
  while (divGrupos.firstChild) {
    divGrupos.removeChild(divGrupos.firstChild);
  }
  // Podía ser en el loop anterior pero me parece más claro separarlo
  for (let i = 0; i < grupos.length; i++) {
    let div = document.createElement("div");
    div.classList.add("grupo");
    //Me armo un span para los nombres
    let span = document.createElement("span");
    let grupo = grupos[i];
    span.textContent = grupo.join(" / ");
    div.appendChild(span);
    // Agrego el grupo al div
    document.getElementById("grupos").appendChild(div);
  }
}
