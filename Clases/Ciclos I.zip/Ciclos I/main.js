let lista = document.getElementById("lista");
let i = 1;
while (i <= 10) {
  let item = document.createElement("li");
  item.textContent = `Item ${i}`;
  lista.appendChild(item);
  i++;
}
