let lista = [
  "primer elemento",
  "segundo elemento",
  "tercer elemento",
  "cuarto elemento",
  "quinto elemento",
];

//Recorrer la lista mediante un ciclo for
console.log("Recorrido de la lista mediante un ciclo for con índices:");
for (let i = 0; i < lista.length; i++) {
  let elemento = lista[i];
  console.log(`${i}) ${elemento}`);
}

//Recorrer la lista mediante un for de iteración
console.log("\nRecorrido de la lista mediante un ciclo for de iteración:");
for (let elemento of lista) {
  console.log(elemento);
}

//Recorrer la lista mediante un forEach
console.log("\nRecorrido de la lista mediante un forEach:");
lista.forEach((elemento) => {
  console.log(elemento);
});

//Recorrer la lista mediante un forEach con índices
console.log("\nRecorrido de la lista mediante un forEach con índices:");
lista.forEach((elemento, i) => {
  console.log(`${i}) ${elemento}`);
});
