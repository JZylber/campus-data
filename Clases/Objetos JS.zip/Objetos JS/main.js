let estudiante = {
  nombre: "Andrea",
  apellido: "Luchetti",
  año: 3,
};
console.log(
  `El estudiante ${estudiante.nombre} ${estudiante.apellido} está en el año ${estudiante.año}`
);
estudiante.nota = 10;
console.log(estudiante);
