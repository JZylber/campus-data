async function catFact() {
  let response = await fetch("https://catfact.ninja/fact");
  let json = await response.json();
  console.log(json.fact);
}

async function main() {
  console.log("Inicio");
  //Prueben sacar y poner el await
  await catFact();
  console.log("Fin");
}

main();
