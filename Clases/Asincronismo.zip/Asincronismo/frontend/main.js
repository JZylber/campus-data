const button = document.getElementById("btn");
const image = document.getElementById("pichicho");
const loader = document.querySelector(".loader");

//No importa mucho esta función
function sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

button.addEventListener("click", async () => {
  loader.classList.remove("hidden");
  image.classList.add("hidden");
  let response = await fetch("https://dog.ceo/api/breeds/image/random");
  let json = await response.json();
  // Espero 2 segundos así se ve el loader: pueden sacarlo si quieren
  await sleep(2000);
  image.src = json.message;
  loader.classList.add("hidden");
  image.classList.remove("hidden");
});
