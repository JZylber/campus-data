function agregarEstudiante() {
  let estudiante = document.getElementById("estudiante");
  let lista = document.getElementById("lista");
  let item = document.createElement("li");
  item.textContent = estudiante.value;
  lista.appendChild(item);
}

document.getElementById("agregar").addEventListener("click", agregarEstudiante);
