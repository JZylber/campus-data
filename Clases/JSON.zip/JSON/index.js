import fs from "fs";

let lista = JSON.parse(fs.readFileSync("tic.json", "utf-8"));
let nuevoDocente = {
  nombre: "Darío",
  rol: "Director",
};
lista.push(nuevoDocente);
fs.writeFileSync("tic.json", JSON.stringify(lista));
