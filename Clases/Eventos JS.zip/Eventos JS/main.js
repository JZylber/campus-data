function click() {
  document.getElementById("cantidad").innerHTML =
    Number(document.getElementById("cantidad").innerHTML) + 1;
}

function onLeave() {
  document.getElementById("presencia").innerHTML = "Mouse afuera";
}

function onEnter() {
  document.getElementById("presencia").innerHTML = "Mouse adentro";
}

document.getElementById("btn").addEventListener("click", click);
document.getElementById("btn").addEventListener("mouseleave", onLeave);
document.getElementById("btn").addEventListener("mouseenter", onEnter);
