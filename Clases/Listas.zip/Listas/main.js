let lista = ["Juan", "Pepe", "Domingo"];
// Obtener elementos de una lista
console.log(lista[1]); //"Pepe"
//Agregar elementos a una lista
lista.push("Carlos");
console.log(lista); //["Juan", "Pepe", "Domingo", "Carlos"]
//Longitud de una lista
console.log(lista.length); //4
//Recorrer una lista
for (let i = 0; i < lista.length; i++) {
  console.log(lista[i]);
}
