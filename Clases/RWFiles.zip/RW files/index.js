import fs from "fs";

let entrada = fs.readFileSync("in.txt", "utf-8");
entrada = "Tu balance es\n" + entrada;
fs.writeFileSync("out.txt", entrada);
