let nota = Number(prompt("Ingrese una nota")) ;
let distrito = prompt("Ingrese distrito");
if(distrito === "capital"){
    if(nota >= 6){
        console.log("Aprobado");
    } else {
        console.log("Desaprobado");
    }
} else if (distrito === "provincia"){
    if(nota >= 7){
        console.log("Aprobado");
    } else {
        console.log("Desaprobado");
    }
} else {
    console.log("No hay información")
}
console.log("Terminado");