/*
Zona P: Solo SkyPriority, Mobilidad reducida y mayores de 80
Zona A: SkyPriority y filas 1 a 25
Zona B: SkyPriority y filas 26 a 45
Zona C: SkyPriority, Mobilidad reducida, mayores de 80 y filas 46 a 60
*/
let fila = Number(prompt("Ingresá la fila"));
let edad = Number(prompt("Ingresá tu edad"));
let prioridad = prompt("Ingresá si tenés prioridad (SkyPriority/Mobilidad reducida/Ninguna)");
let zonaEmbarque = prompt("Ingresá la zona de embarque (P/A/B/C)");
if(zonaEmbarque === "P" && (prioridad === "SkyPriority" || prioridad === "Mobilidad reducida" || edad > 80)){
    console.log("Puede embarcar");
} else if(zonaEmbarque === "A" && (prioridad === "SkyPriority" || (fila >= 1 && fila <= 25))){
    console.log("Puede embarcar");
} else if(zonaEmbarque === "B" && (prioridad === "SkyPriority" || (fila >= 26 && fila <= 45))){
    console.log("Puede embarcar");
} else if(zonaEmbarque === "C" && (prioridad === "SkyPriority" || prioridad === "Mobilidad reducida" || edad > 80 || (fila >= 46 && fila <= 60))){
    console.log("Puede embarcar");
} else {
    console.log("No puede embarcar");
}